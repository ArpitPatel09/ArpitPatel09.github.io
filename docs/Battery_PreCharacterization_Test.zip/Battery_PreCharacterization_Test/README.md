# Battery Pre-Characterization & Resistance Extraction Test (MATLAB / Simulink)

**Author:** Arpit Patel  
**Institution:** Columbia University  
**Project:** Battery Energy Storage Systems (BESS) & Battery Management System (BMS) Modeling  
**Platform:** MATLAB / Simulink R2024b  

---

## 1. Overview & Objective

This test suite implements a standardized **pre-characterization and internal resistance identification test** for lithium-ion battery cells. 

### Core Protocol Sequence:
1. **Phase 1 (C/3 Hybrid Discharge to $V_{min}$):** The battery discharges at a constant $C/3$ rate (with optional periodic 1C hybrid pulse bursts) until the terminal voltage reaches the manufacturer's lower safety cutoff threshold ($V_{min} = 2.80\text{ V}$).
2. **Phase 2 (1-Hour Open Circuit Relaxation at $I = 0$):** Upon reaching $V_{min}$, current immediately drops to zero. The cell rests for exactly 1 hour ($3600\text{ s}$) to allow complete electrochemical relaxation and determine the true equilibrium Open Circuit Voltage at 0% SOC ($V_{OCV,0\%}$).
3. **Phase 3 (C/3 Charging Pulse to $V_{max}$):** The battery is charged at a constant $C/3$ rate until the terminal voltage hits the upper cutoff limit ($V_{max} = 4.20\text{ V}$).
4. **Phase 4 (1-Hour Open Circuit Relaxation at $I = 0$):** Current drops to zero, and the cell rests for 1 hour to reach thermodynamic equilibrium at 100% SOC ($V_{OCV,100\%}$).
5. **Phase 5 (Automated Parameter Extraction):** High-speed edge analysis and exponential curve fitting extract the bulk ohmic resistance ($R_0$), charge-transfer/polarization resistance ($R_1$), time constant ($\tau_1$), double-layer capacitance ($C_1$), and total DCIR ($R_{total}$).

---

## 2. Mathematical Extraction Framework

### A. Ohmic Internal Resistance ($R_0$)
At the transition from load to rest ($t_{cut}^- \to t_{cut}^+$), electrochemical charge transfer dynamics cannot change instantaneously. The immediate vertical voltage step ($\Delta V_0$) across the electrolyte, current collectors, and separator is purely ohmic:

$$R_0 = \frac{|\Delta V_{instantaneous}|}{|\Delta I|} = \frac{|V(t^+) - V(t^-)|}{|I(t^+) - I(t^-)|}$$

* **Discharge Step ($I: -C/3 \to 0\text{ A}$):**
  $$R_{0,dis} = \frac{V(t_{rest1}^+) - V_{min}}{I_{dis}}$$
* **Charge Step ($I: +C/3 \to 0\text{ A}$):**
  $$R_{0,chg} = \frac{V_{max} - V(t_{rest2}^+)}{I_{chg}}$$

### B. Polarization Resistance ($R_1$)
During the 1-hour rest period, the polarization overpotential across the solid-electrolyte interphase (SEI) and diffusion layers decays exponentially back to equilibrium:

$$R_1 = \frac{\Delta V_{polarization}}{|I|} = \frac{|V_{OCV,relaxed} - V(t_{instantaneous}^+)|}{|I|}$$

### C. Polarization Time Constant ($\tau_1$) & Capacitance ($C_1$)
The transient voltage during the rest relaxation phase satisfies:

$$V(t) = V_{OCV} - \Delta V_p \cdot e^{-\frac{t - t_0}{\tau_1}}$$

Transforming into log space:

$$\ln\left(\frac{V_{OCV} - V(t)}{\Delta V_p}\right) = -\frac{1}{\tau_1} (t - t_0)$$

Linear regression yields $\tau_1 = R_1 C_1$, from which the effective double-layer capacitance is extracted:

$$C_1 = \frac{\tau_1}{R_1}$$

### D. Total DC Internal Resistance ($R_{total}$ / DCIR)
$$R_{total} = R_0 + R_1 = \frac{|V_{OCV,relaxed} - V(t_{load}^-)|}{|I|}$$

---

## 3. Directory Structure

```
F:\Project\Battery_PreCharacterization_Test\
├── init_battery_characterization.m          % Battery cell parameters & test protocol setup
├── build_battery_characterization_model.m  % Programmatic Simulink model builder (.slx)
├── battery_characterization_system.slx      % Simulink Model (State machine + 1-RC ECM)
├── extract_battery_resistance.m             % Parameter identification & plotting engine
├── run_battery_characterization.m           % Master 1-click execution script
├── battery_precharacterization_results.png  % Generated 6-panel validation figures
└── README.md                                % Technical documentation
```

---

## 4. How to Run

### Option A: From MATLAB Command Window
```matlab
cd('F:\Project\Battery_PreCharacterization_Test');
run_battery_characterization;
```

### Option B: From Simulink Interactive GUI
1. Open MATLAB and run `init_battery_characterization;` to populate workspace constants.
2. Open `battery_characterization_system.slx`.
3. Press **Run** (Ctrl+T). The simulation will run and automatically halt via the `Stop Simulation` block once the 4 phases finish.
4. Execute `extract_battery_resistance(simOut, Batt, Test);` to see the plots and parameter summary.

---

## 5. Verification Results (Benchmark vs. True Plant)

| Parameter | Extracted | Ground Truth | Error (%) |
| :--- | :---: | :---: | :---: |
| **$R_0$ Ohmic (Discharge)** | **$41.85\text{ m}\Omega$** | $42.00\text{ m}\Omega$ | **$-0.37\%$** |
| **$R_0$ Ohmic (Charge)** | **$42.04\text{ m}\Omega$** | $42.00\text{ m}\Omega$ | **$+0.09\%$** |
| **$R_0$ Ohmic (Average)** | **$41.94\text{ m}\Omega$** | $42.00\text{ m}\Omega$ | **$-0.14\%$** |
| **$R_1$ Polarization** | **$27.95\text{ m}\Omega$** | $28.00\text{ m}\Omega$ | **$-0.19\%$** |
| **$R_{total}$ (DCIR)** | **$69.89\text{ m}\Omega$** | $70.00\text{ m}\Omega$ | **$-0.16\%$** |
| **$\tau_1$ Time Constant** | **$50.3\text{ s}$** | $50.4\text{ s}$ | **$-0.10\%$** |
| **$C_1$ Capacitance** | **$1802\text{ F}$** | $1800\text{ F}$ | **$+0.09\%$** |
