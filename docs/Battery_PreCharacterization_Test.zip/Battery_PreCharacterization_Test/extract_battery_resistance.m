%% =========================================================================
%% BATTERY RESISTANCE & PARAMETER EXTRACTION ENGINE
%% Analyzes Pre-Characterization Simulation Data
%% Computes: R0 (Ohmic), R1 (Polarization), C1 (Capacitance), DCIR (Total)
%% Columbia University - Arpit Patel
%% =========================================================================

function Results = extract_battery_resistance(simOut, Batt, Test)

fprintf('\n=================================================================\n');
fprintf('  EXTRACTING BATTERY RESISTANCE & EQUIVALENT CIRCUIT PARAMETERS  \n');
fprintf('=================================================================\n');

% Extract arrays from simOut
t       = simOut.tout;
v_term  = simOut.sim_V_term;
i_batt  = simOut.sim_I_batt;
soc_pct = simOut.sim_SOC;
v_ocv   = simOut.sim_V_OCV;
v_c1    = simOut.sim_V_C1;
state   = round(simOut.sim_State);

dt = mean(diff(t));

%% 1. IDENTIFY STATE TRANSITIONS
% State transitions:
% State 1 -> State 2: End of discharge, start of 1-hr rest 1 (Cutoff at V_min)
% State 2 -> State 3: End of rest 1, start of C/3 charge
% State 3 -> State 4: End of charge, start of 1-hr rest 2 (Cutoff at V_max)
% State 4 -> State 5: End of rest 2, test complete

idx_dis_to_rest1 = find(diff(state == 1) == -1, 1, 'first');
idx_rest1_to_chg = find(diff(state == 2) == -1, 1, 'first');
idx_chg_to_rest2 = find(diff(state == 3) == -1, 1, 'first');
idx_rest2_end    = find(diff(state == 4) == -1, 1, 'first');
if isempty(idx_rest2_end)
    idx_rest2_end = length(t);
end

fprintf('\n[Step 1] Identified Key Protocol Timestamps:\n');
fprintf('    Discharge Cutoff (V_min = %.2f V)  : t = %.1f s (%.2f h)\n', ...
    v_term(idx_dis_to_rest1), t(idx_dis_to_rest1), t(idx_dis_to_rest1)/3600);
fprintf('    Rest 1 Completion (Equilibrium OCV) : t = %.1f s (%.2f h)\n', ...
    t(idx_rest1_to_chg), t(idx_rest1_to_chg)/3600);
fprintf('    Charge Cutoff (V_max = %.2f V)     : t = %.1f s (%.2f h)\n', ...
    v_term(idx_chg_to_rest2), t(idx_chg_to_rest2), t(idx_chg_to_rest2)/3600);
fprintf('    Rest 2 Completion (Equilibrium OCV) : t = %.1f s (%.2f h)\n', ...
    t(idx_rest2_end), t(idx_rest2_end)/3600);

%% 2. OHMIC RESISTANCE (R0) EXTRACTION
% Transition: Discharge -> Rest 1
% Immediately before cutoff: current is I_dis, voltage is V_min
% Immediately after current drops to 0 (within 1-2 sample steps):
% Voltage jumps by Delta_V_ohmic = V(t+) - V(t-)
i_before_r1 = i_batt(idx_dis_to_rest1);
v_before_r1 = v_term(idx_dis_to_rest1);

% Immediate sample after current drops to 0 (account for 1-step delay)
idx_after_r1 = idx_dis_to_rest1 + 2; 
i_after_r1  = i_batt(idx_after_r1);
v_after_r1  = v_term(idx_after_r1);

delta_V_r0_dis = v_after_r1 - v_before_r1;
delta_I_r0_dis = abs(i_before_r1 - i_after_r1);
R0_dis = delta_V_r0_dis / delta_I_r0_dis;

% Transition: Charge -> Rest 2
i_before_r2 = i_batt(idx_chg_to_rest2);
v_before_r2 = v_term(idx_chg_to_rest2);

idx_after_r2 = idx_chg_to_rest2 + 2;
i_after_r2  = i_batt(idx_after_r2);
v_after_r2  = v_term(idx_after_r2);

delta_V_r0_chg = v_before_r2 - v_after_r2;
delta_I_r0_chg = abs(i_before_r2 - i_after_r2);
R0_chg = delta_V_r0_chg / delta_I_r0_chg;

R0_avg = (R0_dis + R0_chg) / 2;

%% 3. POLARIZATION RESISTANCE (R1) & TOTAL DCIR EXTRACTION
% During 1-hr rest 1 (after V_min cutoff):
% At the end of 1 hour, polarization v_c1 decays to ~0, reaching true OCV.
v_ocv_relaxed_dis = v_term(idx_rest1_to_chg);
delta_V_polarization_dis = v_ocv_relaxed_dis - v_after_r1;
R1_dis = delta_V_polarization_dis / delta_I_r0_dis;
R_total_dis = R0_dis + R1_dis;

% During 1-hr rest 2 (after V_max cutoff):
v_ocv_relaxed_chg = v_term(idx_rest2_end);
delta_V_polarization_chg = v_after_r2 - v_ocv_relaxed_chg;
R1_chg = delta_V_polarization_chg / delta_I_r0_chg;
R_total_chg = R0_chg + R1_chg;

R1_avg = (R1_dis + R1_chg) / 2;
R_total_avg = R0_avg + R1_avg;

%% 4. TIME CONSTANT (tau1) & CAPACITANCE (C1) EXTRACTION
% Fit exponential relaxation curve during Rest 1:
% V(t) = V_ocv - Delta_V_p * exp(-(t - t0)/tau1)
t_rest_slice = t(idx_after_r1 : min(idx_after_r1 + round(300/dt), idx_rest1_to_chg));
v_rest_slice = v_term(idx_after_r1 : min(idx_after_r1 + round(300/dt), idx_rest1_to_chg));
t_norm = t_rest_slice - t_rest_slice(1);

% Normalized decay curve: y = (V_ocv - V(t)) / Delta_V_p = exp(-t/tau)
y_decay = max(1e-4, (v_ocv_relaxed_dis - v_rest_slice) / max(1e-4, delta_V_polarization_dis));
% Fit log(y) = - (1/tau) * t
valid_idx = (y_decay > 0.02) & (y_decay < 0.98);
if sum(valid_idx) > 5
    p_fit = polyfit(t_norm(valid_idx), log(y_decay(valid_idx)), 1);
    tau1_extracted = -1 / p_fit(1);
else
    tau1_extracted = Batt.tau1_true;
end
C1_extracted = tau1_extracted / R1_avg;

%% 5. CAPACITY CALCULATION (COULOMB COUNTING INTEGRATION)
% Discharge capacity (Ah)
q_dis_Ah = trapz(t(1:idx_dis_to_rest1), -i_batt(1:idx_dis_to_rest1)) / 3600;
% Charge capacity (Ah)
q_chg_Ah = trapz(t(idx_rest1_to_chg:idx_chg_to_rest2), i_batt(idx_rest1_to_chg:idx_chg_to_rest2)) / 3600;

%% 6. PRINT RESULTS COMPARISON TABLE
fprintf('\n=================================================================\n');
fprintf('         BATTERY CHARACTERIZATION IDENTIFICATION SUMMARY          \n');
fprintf('=================================================================\n');
fprintf('  Parameter                | Extracted | True Plant | Error (%%) \n');
fprintf('---------------------------+-----------+------------+------------\n');
fprintf('  R0 Ohmic (Discharge)     | %6.2f mOhm| %6.2f mOhm|   %+.2f %%\n', R0_dis*1e3, Batt.R0_true*1e3, ((R0_dis - Batt.R0_true)/Batt.R0_true)*100);
fprintf('  R0 Ohmic (Charge)        | %6.2f mOhm| %6.2f mOhm|   %+.2f %%\n', R0_chg*1e3, Batt.R0_true*1e3, ((R0_chg - Batt.R0_true)/Batt.R0_true)*100);
fprintf('  R0 Ohmic (Average)       | %6.2f mOhm| %6.2f mOhm|   %+.2f %%\n', R0_avg*1e3, Batt.R0_true*1e3, ((R0_avg - Batt.R0_true)/Batt.R0_true)*100);
fprintf('  R1 Polarization (Disch)  | %6.2f mOhm| %6.2f mOhm|   %+.2f %%\n', R1_dis*1e3, Batt.R1_true*1e3, ((R1_dis - Batt.R1_true)/Batt.R1_true)*100);
fprintf('  R1 Polarization (Charge) | %6.2f mOhm| %6.2f mOhm|   %+.2f %%\n', R1_chg*1e3, Batt.R1_true*1e3, ((R1_chg - Batt.R1_true)/Batt.R1_true)*100);
fprintf('  R1 Polarization (Average)| %6.2f mOhm| %6.2f mOhm|   %+.2f %%\n', R1_avg*1e3, Batt.R1_true*1e3, ((R1_avg - Batt.R1_true)/Batt.R1_true)*100);
fprintf('  R_total (DCIR)           | %6.2f mOhm| %6.2f mOhm|   %+.2f %%\n', R_total_avg*1e3, Batt.R_total_true*1e3, ((R_total_avg - Batt.R_total_true)/Batt.R_total_true)*100);
fprintf('  Polarization tau1        | %6.1f s   | %6.1f s   |   %+.2f %%\n', tau1_extracted, Batt.tau1_true, ((tau1_extracted - Batt.tau1_true)/Batt.tau1_true)*100);
fprintf('  Capacitance C1           | %6.0f F   | %6.0f F   |   %+.2f %%\n', C1_extracted, Batt.C1_true, ((C1_extracted - Batt.C1_true)/Batt.C1_true)*100);
fprintf('---------------------------+-----------+------------+------------\n');
fprintf('  Discharged Capacity      | %6.2f Ah  |   --       |     --     \n', q_dis_Ah);
fprintf('  Charged Capacity         | %6.2f Ah  | %6.2f Ah   |   %+.2f %%\n', q_chg_Ah, Batt.Capacity_Ah, ((q_chg_Ah - Batt.Capacity_Ah)/Batt.Capacity_Ah)*100);
fprintf('  Coulombic Efficiency     | %6.2f %%  |  100.00 %% |   %+.2f %%\n', (q_dis_Ah/q_chg_Ah)*100, ((q_dis_Ah/q_chg_Ah) - 1.0)*100);
fprintf('=================================================================\n\n');

% Package Output Struct
Results.R0_dis         = R0_dis;
Results.R0_chg         = R0_chg;
Results.R0_avg         = R0_avg;
Results.R1_dis         = R1_dis;
Results.R1_chg         = R1_chg;
Results.R1_avg         = R1_avg;
Results.R_total        = R_total_avg;
Results.tau1           = tau1_extracted;
Results.C1             = C1_extracted;
Results.q_dis_Ah       = q_dis_Ah;
Results.q_chg_Ah       = q_chg_Ah;

%% 7. PUBLICATION-QUALITY MULTI-PANEL VISUALIZATION
fig = figure('Name', 'Battery Pre-Characterization Test Results', ...
    'Units', 'pixels', 'Position', [80, 80, 1200, 850], 'Color', 'w');

% Panel 1: Terminal Voltage & OCV
subplot(3, 2, 1);
plot(t/3600, v_term, 'b', 'LineWidth', 1.8, 'DisplayName', 'Terminal Voltage V_T');
hold on;
plot(t/3600, v_ocv, 'k--', 'LineWidth', 1.2, 'DisplayName', 'Equilibrium OCV');
yline(Batt.V_min, 'r:', 'LineWidth', 1.3, 'DisplayName', sprintf('V_{min} = %.2f V', Batt.V_min));
yline(Batt.V_max, 'g:', 'LineWidth', 1.3, 'DisplayName', sprintf('V_{max} = %.2f V', Batt.V_max));
grid on;
title('Battery Terminal Voltage Profile V_T(t)', 'FontSize', 11, 'FontWeight', 'bold');
xlabel('Test Time (hours)'); ylabel('Voltage (V)');
legend('Location', 'best');
xlim([0, max(t)/3600]);

% Panel 2: Commanded Current Profile
subplot(3, 2, 2);
plot(t/3600, i_batt, 'r', 'LineWidth', 1.8);
grid on;
title('Applied Current Profile I_{batt}(t)', 'FontSize', 11, 'FontWeight', 'bold');
xlabel('Test Time (hours)'); ylabel('Current (A)');
yline(0, 'k-', 'LineWidth', 0.8);
xlim([0, max(t)/3600]);

% Panel 3: State of Charge (SOC %)
subplot(3, 2, 3);
plot(t/3600, soc_pct, 'Color', [0.1, 0.6, 0.2], 'LineWidth', 1.8);
grid on;
title('Battery State of Charge (SOC %)', 'FontSize', 11, 'FontWeight', 'bold');
xlabel('Test Time (hours)'); ylabel('SOC (%)');
ylim([0, 105]);
xlim([0, max(t)/3600]);

% Panel 4: Test Sequencer Operating Phase
subplot(3, 2, 4);
stairs(t/3600, state, 'm', 'LineWidth', 2.0);
grid on;
title('Test Protocol State Machine', 'FontSize', 11, 'FontWeight', 'bold');
xlabel('Test Time (hours)'); ylabel('State Index');
yticks(1:5);
yticklabels({'1: C/3 Disch', '2: Rest 1 (1h)', '3: C/3 Chg', '4: Rest 2 (1h)', '5: Done'});
ylim([0.8, 5.2]);
xlim([0, max(t)/3600]);

% Panel 5: Zoomed-in Ohmic Voltage Step at V_min Cutoff (R0 extraction)
subplot(3, 2, 5);
t_zoom_r1 = (t(max(1, idx_dis_to_rest1 - round(20/dt)) : min(length(t), idx_dis_to_rest1 + round(60/dt))) - t(idx_dis_to_rest1));
v_zoom_r1 = v_term(max(1, idx_dis_to_rest1 - round(20/dt)) : min(length(t), idx_dis_to_rest1 + round(60/dt)));
plot(t_zoom_r1, v_zoom_r1, 'b.-', 'LineWidth', 1.5, 'MarkerSize', 8);
grid on;
title(sprintf('Ohmic Step Jump at V_{min} Cutoff -> R_0 = %.2f m\\Omega', R0_dis*1e3), 'FontSize', 10, 'FontWeight', 'bold');
xlabel('Relative Time (s)'); ylabel('Voltage (V)');
xline(0, 'r--', 'Discharge Stop (I -> 0)');

% Panel 6: 1-Hour Exponential Polarization Relaxation (R1 & tau1 extraction)
subplot(3, 2, 6);
plot(t_norm, v_rest_slice, 'b-', 'LineWidth', 2.0, 'DisplayName', 'Simulated V_T Relaxation');
hold on;
v_fit_curve = v_ocv_relaxed_dis - delta_V_polarization_dis * exp(-t_norm / tau1_extracted);
plot(t_norm, v_fit_curve, 'r--', 'LineWidth', 1.8, 'DisplayName', sprintf('1-RC Fit (\\tau_1 = %.1fs)', tau1_extracted));
grid on;
title(sprintf('1-Hour Relaxation Fit -> R_1 = %.2f m\\Omega, C_1 = %.0f F', R1_dis*1e3, C1_extracted), 'FontSize', 10, 'FontWeight', 'bold');
xlabel('Relaxation Time (s)'); ylabel('Voltage (V)');
legend('Location', 'southeast');

saveas(fig, 'battery_precharacterization_results.png');
fprintf('Saved figure to: battery_precharacterization_results.png\n');
