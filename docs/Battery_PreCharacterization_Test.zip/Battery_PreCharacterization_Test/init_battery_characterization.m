%% =========================================================================
%% BATTERY PRE-CHARACTERIZATION & RESISTANCE EXTRACTION INITIALIZATION
%% Columbia University - Arpit Patel
%% Protocol: C/3 Hybrid Discharge -> Vmin Cutoff -> 1h Rest (OCV) ->
%%           Charging Pulse -> Vmax Cutoff -> 1h Rest -> Parameter ID
%% =========================================================================


%Battery: 
%%
% <www.18650batterystore.com/products/samsung-25r-18650>viewBaattery%


fprintf('=================================================================\n');
fprintf('  Initializing Battery Pre-Characterization Test Protocol        \n');
fprintf('=================================================================\n\n');

%% 1. BATTERY CELL SPECIFICATIONS (Automotive Li-ion Cell)
Batt.CellType      = 'NMC / Graphite 18650-21700';
Batt.Capacity_Ah   = 2.5;                     % Rated capacity in Ampere-hours (Ah)
Batt.Capacity_C    = Batt.Capacity_Ah * 3600; % Rated capacity in Coulombs (As = 9000 C)
Batt.V_nom         = 3.70;                    % Nominal voltage (V)
Batt.V_max         = 4.20;                    % Maximum charge cutoff voltage (V)
Batt.V_min         = 2.80;                    % Minimum discharge cutoff voltage (V)
Batt.SOC_init      = 0.50;                    % Initial State of Charge (50% for fast test demo)

% True Physical Parameters for 1-RC Thevenin ECM (Used by Plant)
Batt.R0_true       = 0.042;                   % Ohmic Internal Resistance (42 mOhm)
Batt.R1_true       = 0.028;                   % Charge Transfer / Polarization Resistance (28 mOhm)
Batt.C1_true       = 1800.0;                  % Double-layer Polarization Capacitance (Farads)
Batt.tau1_true     = Batt.R1_true * Batt.C1_true; % Polarization Time Constant (50.4 s)
Batt.R_total_true  = Batt.R0_true + Batt.R1_true; % True Total DCIR (70 mOhm)

% Open Circuit Voltage (OCV) vs SOC Lookup Table (NMC typical curve)
Batt.SOC_table = [0.00, 0.05, 0.10, 0.20, 0.30, 0.40, 0.50, ...
                  0.60, 0.70, 0.80, 0.90, 0.95, 1.00];
Batt.OCV_table = [2.85, 3.32, 3.48, 3.62, 3.70, 3.76, 3.82, ...
                  3.89, 3.96, 4.05, 4.14, 4.18, 4.20];

fprintf('[1] Cell Specification:\n');
fprintf('    Nominal: %.2f V | Capacity: %.2f Ah (%.0f Coulombs)\n', Batt.V_nom, Batt.Capacity_Ah, Batt.Capacity_C);
fprintf('    Voltage Limits: V_min = %.2f V, V_max = %.2f V\n', Batt.V_min, Batt.V_max);
fprintf('    True ECM Plant Values: R0 = %.1f mOhm, R1 = %.1f mOhm, tau = %.1f s\n\n', ...
    Batt.R0_true*1e3, Batt.R1_true*1e3, Batt.tau1_true);

%% 2. TEST PROTOCOL CONFIGURATION
% C-rate definitions: Positive current = Charging, Negative current = Discharging
Test.C_rate_dis    = 1/3;                     % C/3 discharge rate
Test.I_dis_mag     = Batt.Capacity_Ah * Test.C_rate_dis; % ~0.833 A
Test.I_dis_cmd     = -Test.I_dis_mag;         % Discharging is negative current in ECM conventions

Test.C_rate_chg    = 1/3;                     % C/3 charge rate
Test.I_chg_cmd     = Batt.Capacity_Ah * Test.C_rate_chg; % +0.833 A

% Rest Durations (seconds)
Test.T_rest_1_s    = 3600.0;                  % 1 hour rest after reaching V_min (3600 s)
Test.T_rest_2_s    = 3600.0;                  % 1 hour rest after reaching V_max (3600 s)

% Hybrid Pulse Overlay Settings (Optional periodic pulse during discharge)
% If enabled, periodically injects a 10s pulse of 1C discharge to observe instantaneous R0 vs SOC
Test.enable_hybrid_pulses = 1;                % 1 = Enable pulse train, 0 = Continuous C/3
Test.pulse_period_s       = 600.0;            % Every 10 minutes (600 s)
Test.pulse_duration_s     = 10.0;             % 10-second pulse
Test.pulse_current_mag    = Batt.Capacity_Ah * 1.0; % 1C pulse (2.5 A)

fprintf('[2] Test Protocol Loaded:\n');
fprintf('    Phase 1: C/3 Discharge (%.3f A) until V_term <= %.2f V\n', abs(Test.I_dis_cmd), Batt.V_min);
fprintf('    Phase 2: Rest at I = 0 A for %.1f hours (%.0f s) to reach OCV\n', Test.T_rest_1_s/3600, Test.T_rest_1_s);
fprintf('    Phase 3: C/3 Charge (%.3f A) until V_term >= %.2f V\n', Test.I_chg_cmd, Batt.V_max);
fprintf('    Phase 4: Rest at I = 0 A for %.1f hours (%.0f s) to reach OCV\n', Test.T_rest_2_s/3600, Test.T_rest_2_s);
fprintf('    Phase 5: Automated Resistance Extraction (R0, R1, C1, DCIR)\n\n');

%% 3. SIMULATION SOLVER CONFIGURATION
SimConfig.Ts       = 0.1;                     % 100 ms sample time (ideal for capturing ms step and hr relaxation)
SimConfig.MaxTime  = 30000.0;                 % Upper simulation stop bound (s) (~8.3 hours)
