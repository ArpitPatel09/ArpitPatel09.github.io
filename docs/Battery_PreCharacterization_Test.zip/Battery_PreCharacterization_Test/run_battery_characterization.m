%% =========================================================================
%% MASTER RUNNER: BATTERY PRE-CHARACTERIZATION & RESISTANCE EXTRACTION
%% Runs Simulink Model & Extracts R0, R1, C1, and DCIR Parameters
%% Columbia University - Arpit Patel
%% =========================================================================

clear; clc; close all;

curDir = fileparts(mfilename('fullpath'));
if isempty(curDir)
    curDir = pwd;
end
cd(curDir);

fprintf('=================================================================\n');
fprintf('  STARTING BATTERY PRE-CHARACTERIZATION SIMULINK WORKFLOW         \n');
fprintf('=================================================================\n\n');

% 1. Load Parameters
init_battery_characterization;

% 2. Check and Build Model if not already compiled
modelName = 'battery_characterization_system';
if ~exist([modelName, '.slx'], 'file')
    fprintf('Simulink model not found. Building %s.slx ...\n', modelName);
    build_battery_characterization_model;
else
    fprintf('Found existing model: %s.slx\n', modelName);
end

% 3. Run Simulation
fprintf('\nExecuting Simulink Simulation of Test Protocol ...\n');
tic;
simOut = sim(modelName, 'StopTime', num2str(SimConfig.MaxTime));
simTime = toc;
fprintf('Simulation completed in %.2f seconds!\n', simTime);

% 4. Extract Parameters and Generate Plots
Results = extract_battery_resistance(simOut, Batt, Test);

fprintf('\nPre-characterization workflow finished successfully!\n');
